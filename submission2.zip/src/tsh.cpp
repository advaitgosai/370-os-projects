#include <tsh.h>
#include <iostream>
#include <cstring>

using namespace std;

void simple_shell::parse_command(char* cmd, char** cmdTokens) {
    // TODO: tokenize the command string into arguments
    int index = 0;
    char* token = strtok(cmd, " \n");
    while (token != NULL) {
        cmdTokens[index] = token;
        index++;
        token = strtok(NULL, " \n");
    }
    cmdTokens[index] = NULL;
}

void simple_shell::exec_command(char** argv) {
    // TODO: fork a child process to execute the command.
    // parent process should wait for the child process to complete and reap it
    int pid = fork();
    if (pid == 0) {
        execvp(argv[0], argv);
    }
    else {
        int wc = wait(NULL);
    }
}

bool simple_shell::isQuit(char* cmd) {
    // TODO: check for the command "quit" that terminates the shell
    if (strcmp("quit", cmd) == 0) return true;
    return false;
}
