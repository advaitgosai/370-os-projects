#include <scheduling.h>
#include <fstream>
#include <iostream>
#include <list>
#include <queue>
#include <string>
#include <sstream>

using namespace std;

pqueue_arrival read_workload(string filename) {
  pqueue_arrival workload;
  ifstream input(filename);
  string line;
  if (input.is_open() == 1) {
    while (getline(input, line)) {
      Process p;
      istringstream iss(line);
      int a,b;
      iss >> a >> b;
      p.arrival = a;
      p.duration = b;
      p.first_run = -2; //Assigning negative value to indicate process is yet to be run
      workload.push(p);
    }
  }
  else {
    cout << "Error opening file.";
    exit(1);
  }

  return workload;
}

void show_workload(pqueue_arrival workload) {
  pqueue_arrival xs = workload;
  cout << "Workload:" << endl;
  while (!xs.empty()) {
    Process p = xs.top();
    cout << '\t' << p.arrival << ' ' << p.duration << endl;
    xs.pop();
  }
}

void show_processes(list<Process> processes) {
  list<Process> xs = processes;
  cout << "Processes:" << endl;
  while (!xs.empty()) {
    Process p = xs.front();
    cout << "\tarrival=" << p.arrival << ", duration=" << p.duration
         << ", first_run=" << p.first_run << ", completion=" << p.completion
         << endl;
    xs.pop_front();
  }
}

list<Process> fifo(pqueue_arrival workload) {
  list<Process> complete;
  pqueue_arrival xs = workload;
  int currtime = 0;
  int size = xs.size();
  for (int i = 0; i < size; ++i) {
    Process p = xs.top();
    if (currtime < p.arrival) {
      currtime = p.arrival;
    }
    p.first_run = currtime;
    currtime += p.duration;
    p.completion = currtime;
    xs.pop();
    complete.push_back(p);
  }
  return complete;
}

list<Process> sjf(pqueue_arrival workload) {
  list<Process> complete;
  pqueue_arrival xs = workload;
  int currtime = 0;
  int size = xs.size();
  for (int i = 0; i < size; ++i) {
    Process p = xs.top();
    if (currtime < p.arrival) {
      currtime = p.arrival;
    }
    p.first_run = currtime;
    currtime += p.duration;
    p.completion = currtime;
    xs.pop();
    complete.push_back(p);
  }
  return complete;
}

list<Process> stcf(pqueue_arrival workload) {
  list<Process> complete;
  pqueue_arrival xs = workload;
  pqueue_duration arrived;
  Process p1, p2;
  int currtime = 0;

  arrived.push(xs.top());
  p1 = arrived.top();
  xs.pop();
  p2 = xs.top();

  while (complete.size() < workload.size()) {
    if (p2.arrival != currtime) {
      if (p1.first_run == -2) {
        p1.first_run = currtime;
      }
      if (p1.duration == 0) {
        p1.completion = currtime;
        complete.push_back(p1);
        arrived.pop();
        p1 = arrived.top();
      }
      else {
        currtime++;
        p1.duration--;
      }
    }
    else {
      if (p1.first_run != -2){
        arrived.push(p1);
      }
      arrived.push(p2);
      xs.pop();
      p1 = arrived.top();
      if (xs.empty()) {
        p2.arrival = -1;
        p2.duration = -1;
      }
      else {
        p2 = xs.top();
      }
    }
  }
  return complete;
}


list<Process> rr(pqueue_arrival workload) {
  list<Process> complete;
  pqueue_arrival xs = workload;
  queue<Process> q;
  int currtime = 0;
  Process p1;
  Process p2 = xs.top();
  xs.pop();
  while (complete.size() < workload.size()) {
    if (p2.arrival == currtime) {
      q.push(p2);
      if (xs.size() == 0) {
        p2.arrival = -1;
        p2.duration = -1;
      }
      else {
        p2 = xs.top();
        xs.pop();
      }
    }
    else if (q.size() != 0) {
      p1 = q.front();
      q.pop();

      if (p1.first_run == -2) {
          p1.first_run = currtime;
      }
      p1.duration--;
      currtime++;
      if (p1.duration == 0) {
        p1.completion = currtime;
        complete.push_back(p1);
      }
      else {
        q.push(p1);
      }
    }
  }
  return complete;
}

float avg_turnaround(list<Process> processes) {
  list<Process>::iterator it;
  list<Process> xs = processes;
  int tat = 0;
  for (it = xs.begin(); it != xs.end(); ++it) {
    tat += (it->completion - it->arrival);
  }
  return float(tat) / float(processes.size());
}

float avg_response(list<Process> processes) {
  list<Process>::iterator it;
  list<Process> xs = processes;
  int response = 0;
  for (it = xs.begin(); it != xs.end(); ++it) {
    response += (it->first_run - it->arrival);
  }
  return float(response) / float(processes.size());
}

void show_metrics(list<Process> processes) {
  float avg_t = avg_turnaround(processes);
  float avg_r = avg_response(processes);
  show_processes(processes);
  cout << '\n';
  cout << "Average Turnaround Time: " << avg_t << endl;
  cout << "Average Response Time:   " << avg_r << endl;
}
