#include <ProducerConsumer.h>
#include <thread>

// TODO: add BoundedBuffer, locks and any global variables here
BoundedBuffer buffer(20);
ofstream ofile("output.txt");
pthread_mutex_t prodlock = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t conslock = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t printlock = PTHREAD_MUTEX_INITIALIZER;
pthread_t *prthreads;
pthread_t *cthreads;
chrono::system_clock::time_point initial_time;
int total_items;
int psleep_time;
int csleep_time;
int pshared;
int cshared;

void InitProducerConsumer(int p, int c, int psleep, int csleep, int items) {
  // TODO: constructor to initialize variables declared
  //       also see instructions on the implementation
  initial_time = chrono::system_clock::now();
  psleep_time = psleep;
  csleep_time = csleep;
  total_items = items;
  pshared = 0;
  cshared = 0;
  prthreads = (pthread_t*) malloc(p*sizeof(pthread_t));
  cthreads = (pthread_t*) malloc(c*sizeof(pthread_t));
  int pr_index[p];
  int cr_index[c];
  for (int i = 0; i < p; ++i) {
    pr_index[i] = i; 
    pthread_create(&prthreads[i], NULL, producer, (void*)&pr_index[i]);
  }
  for (int i = 0; i < c; ++i) {
    cr_index[i] = i; 
    pthread_create(&prthreads[i], NULL, consumer, (void*)&cr_index[i]);
  }
  for (int i = 0; i < p; ++i) {
    pthread_join(prthreads[i], NULL);
  }
  for (int i = 0; i < c; ++i) {
    pthread_join(cthreads[i], NULL);
  }
}

void* producer(void* threadID) {
  // TODO: producer thread, see instruction for implementation
  while (pshared < total_items) {
    this_thread::sleep_for(chrono::milliseconds(psleep_time));
    pthread_mutex_lock(&prodlock);
    if (pshared >= total_items) {
      pthread_mutex_unlock(&prodlock);
      break;  
    }
    int data = rand();
    pshared++;
    buffer.append(data);
    chrono::duration<double> elapsed = chrono::system_clock::now() - initial_time;
    pthread_mutex_lock(&printlock);
    ofile << "Producer #" << *(int *)(threadID)+1 << ", time = " << elapsed.count() << ", producing data item #" << pshared << ", item value=" << data << endl;
    pthread_mutex_unlock(&printlock); 
    pthread_mutex_unlock(&prodlock);
  }
  return NULL;
}

void* consumer(void* threadID) {
  // TODO: consumer thread, see instruction for implementation
  while (cshared < total_items) {
    this_thread::sleep_for(chrono::milliseconds(csleep_time));
    pthread_mutex_lock(&conslock);
    if (cshared >= total_items) {
      pthread_mutex_unlock(&conslock);
      break;  
    }
    int data = buffer.remove();
    cshared++;
    chrono::duration<double> elapsed = chrono::system_clock::now() - initial_time;
    pthread_mutex_lock(&printlock);
    ofile << "Consumer #" << *(int *)(threadID)+1 << ", time = " << elapsed.count() << ", consuming data item with value=" << data << endl;
    pthread_mutex_unlock(&printlock); 
    pthread_mutex_unlock(&conslock);
  }
  return NULL;
}
