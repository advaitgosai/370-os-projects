#include <BoundedBuffer.h>

BoundedBuffer::BoundedBuffer(int N) {
  // TODO: constructor to initiliaze all the varibales declared in
  buffer = (int*) malloc(N*sizeof(int));
  buffer_size = N;
  buffer_cnt = 0;
  buffer_first = 0;
  buffer_last = 0;
}

BoundedBuffer::~BoundedBuffer() {
  // TODO: destructor to clean up anything necessary
  pthread_mutex_lock(&buffer_lock);
  buffer_cnt = 0;
  free(buffer);
  pthread_mutex_unlock(&buffer_lock);
}

void BoundedBuffer::append(int data) {
  // TODO: append a data item to the circular buffer
  pthread_mutex_lock(&buffer_lock);
  while (buffer_cnt == buffer_size) {
    pthread_cond_wait(&buffer_not_full, &buffer_lock);
  }
  buffer[buffer_last] = data;
  buffer_last = (buffer_last+1) % buffer_size;
  buffer_cnt++;
  pthread_cond_signal(&buffer_not_empty);
  pthread_mutex_unlock(&buffer_lock);
}

int BoundedBuffer::remove() {
  // TODO: remove and return a data item from the circular buffer
  pthread_mutex_lock(&buffer_lock);
  while (buffer_cnt == 0) {
    pthread_cond_wait(&buffer_not_empty, &buffer_lock);
  }
  int first = buffer[buffer_first];
  buffer_first = (buffer_first + 1) % buffer_size;
  buffer_cnt--;
  pthread_cond_signal(&buffer_not_full);
  pthread_mutex_unlock(&buffer_lock);
  return first;
}

bool BoundedBuffer::isEmpty() {
  // TODO: check is the buffer is empty
  return buffer_cnt == 0;
}
