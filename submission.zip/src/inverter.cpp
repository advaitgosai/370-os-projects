#include <map>
#include <queue>
#include <set>
#include <string>
#include <fstream>
#include <iostream>

#include <inverter.h>

using namespace std;

string print_set(set<int> s) {
  string output;
  for (auto item = s.begin(); item != s.end(); item++) {
    output = output + " " + to_string((*item));
  }
  return output;
}

string build_inverted_index(string filename) {
  string output;
  int fileCount = 0;
  map<string, set<int>> invertedIndex;
  ifstream inputFileStream;
  inputFileStream.open(filename);
  if (inputFileStream.is_open()){
    while(inputFileStream) {
      ifstream currFileStream;
      string currFile;
      getline(inputFileStream, currFile);
      currFileStream.open(currFile);
      string word;
      while (currFileStream >> word) {
        string actualWord = "";
        for (int i = 0; i < word.length(); i++) {
          if ((word[i] >= 65 && word[i] <= 90) || (word[i] >= 97 && word[i] <= 122)) {
            actualWord += word[i];
          }
          else {
            if (actualWord.compare("")!= 0) {
              if(invertedIndex.find(actualWord) != invertedIndex.end()) {
                invertedIndex[actualWord].insert(fileCount);
              }
              else {
                set<int> temp;
                temp.insert(fileCount);
                invertedIndex.insert(pair<string, set<int>>(actualWord, temp));
              }
              actualWord = "";
            }
          }
        }
        if (actualWord.compare("")!= 0) {
          if(invertedIndex.find(actualWord) != invertedIndex.end()) {
            invertedIndex[actualWord].insert(fileCount);
          }
          else {
            set<int> temp;
            temp.insert(fileCount);
            invertedIndex.insert(pair<string, set<int>>(actualWord, temp));
          }
          actualWord = "";
        }
      }
      currFileStream.close();
      fileCount++;
    }
    inputFileStream.close();
  }
  for (auto item = invertedIndex.begin(); item != invertedIndex.end(); item++) {
    output = output + item->first + ":" + print_set(item->second) + "\n";
    //cout << item->first << ":" << print_set(item->second) << endl;
  }
  return output;
}
